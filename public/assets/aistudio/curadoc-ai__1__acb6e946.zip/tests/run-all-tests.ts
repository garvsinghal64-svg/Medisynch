import { runClinicalSafetyTests } from './clinical-safety.test';
import { runVitalsAndHeuristicsTests } from './vitals-and-heuristics.test';
import { runFhirHl7Tests } from './fhir-hl7.test';
import { runDataMaskerAndAuditTests } from './data-masker-and-audit.test';
import { runDbPersistenceTests } from './db-persistence.test';

async function main() {
  console.log('================================================================');
  console.log('  CURADOC AI CLINICAL WORKSPACE — AUTOMATED TEST SUITE');
  console.log('  Verification of Safety, Heuristics, FHIR, DB & Security Rules');
  console.log('================================================================\n');

  const allTestSuites = [
    { suite: 'Clinical Safety & Drug Interactions', fn: runClinicalSafetyTests },
    { suite: 'Vitals Normalization & Clinical Heuristics', fn: runVitalsAndHeuristicsTests },
    { suite: 'FHIR R4 & HL7 v2.5.1 Message Construction', fn: runFhirHl7Tests },
    { suite: 'HIPAA PHI Data Masking & Audit Trail', fn: runDataMaskerAndAuditTests },
    { suite: 'Clinical Database CRUD, Revisions & Sync', fn: runDbPersistenceTests },
  ];

  let totalTests = 0;
  let passedTests = 0;
  let failedTests = 0;

  for (const { suite, fn } of allTestSuites) {
    console.log(`▶ Running Suite: ${suite}`);
    const results = fn();
    for (const res of results) {
      totalTests++;
      if (res.passed) {
        passedTests++;
        console.log(`  ✔ [PASS] ${res.name}`);
      } else {
        failedTests++;
        console.error(`  ✖ [FAIL] ${res.name}`);
        if (res.details) {
          console.error(`      Reason: ${res.details}`);
        }
      }
    }
    console.log('');
  }

  console.log('================================================================');
  console.log(`  TEST RESULTS SUMMARY:`);
  console.log(`  Total:  ${totalTests}`);
  console.log(`  Passed: ${passedTests}`);
  console.log(`  Failed: ${failedTests}`);
  console.log('================================================================');

  if (failedTests > 0) {
    console.error(`\nFAILED: ${failedTests} test(s) failed. Inspect outputs above.`);
    process.exit(1);
  } else {
    console.log('\nSUCCESS: All clinical verification tests passed cleanly!');
    process.exit(0);
  }
}

main();
