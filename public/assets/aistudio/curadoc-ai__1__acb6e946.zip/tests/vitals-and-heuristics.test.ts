import { parseBloodPressure, parseTemperature, computeMeanArterialPressure } from '../src/utils/vitalsParser';
import { runHeuristicClinicalAnalysis } from '../src/utils/clinicalHeuristics';
import { CLINICAL_CASES } from '../src/data/clinicalTemplates';

export function runVitalsAndHeuristicsTests(): { name: string; passed: boolean; details?: string }[] {
  const results: { name: string; passed: boolean; details?: string }[] = [];

  // Test 1: Blood Pressure Parsing & Mean Arterial Pressure (MAP)
  try {
    const bp = parseBloodPressure('138/86 mmHg');
    if (bp && bp.systolic === 138 && bp.diastolic === 86) {
      const map = computeMeanArterialPressure(138, 86);
      // MAP = DBP + 1/3(SBP - DBP) = 86 + 1/3(52) = 86 + 17.33 = 103.3 mmHg
      if (Math.round(map) === 103) {
        results.push({ name: 'Blood Pressure Parser & MAP Computation Accurate', passed: true });
      } else {
        results.push({
          name: 'Blood Pressure Parser & MAP Computation Accurate',
          passed: false,
          details: `Expected MAP around 103 mmHg, got ${map}`,
        });
      }
    } else {
      results.push({
        name: 'Blood Pressure Parser & MAP Computation Accurate',
        passed: false,
        details: `Failed to parse 138/86: got ${JSON.stringify(bp)}`,
      });
    }
  } catch (err: any) {
    results.push({ name: 'Blood Pressure Parser & MAP Computation', passed: false, details: err.message });
  }

  // Test 2: Temperature Unit Conversion (Fahrenheit to Celsius)
  try {
    const tempF = parseTemperature('101.4 °F');
    // (101.4 - 32) * 5/9 = 38.55 °C
    if (tempF && Math.abs(tempF.celsius - 38.6) < 0.2) {
      results.push({ name: 'Temperature Parser & Fahrenheit-to-Celsius Normalization', passed: true });
    } else {
      results.push({
        name: 'Temperature Parser & Fahrenheit-to-Celsius Normalization',
        passed: false,
        details: `Expected ~38.6 C, got ${tempF?.celsius}`,
      });
    }
  } catch (err: any) {
    results.push({ name: 'Temperature Parser', passed: false, details: err.message });
  }

  // Test 3: Clinical Decision Heuristics - Cardiology Case Analysis
  try {
    const cardioCase = CLINICAL_CASES[0];
    const analysis = runHeuristicClinicalAnalysis(cardioCase.initialNote, cardioCase.patient);

    const hasDifferentials = analysis.differentials && analysis.differentials.length >= 2;
    const hasIcd10 = analysis.icd10Suggestions && analysis.icd10Suggestions.length >= 1;
    const hasPatientSummary = Boolean(analysis.patientSummary?.headline && analysis.patientSummary?.keyInstructions?.length);
    const hasMissingHistory = (analysis.missingHistoryQuestions?.length || 0) > 0;
    const hasMissingExam = (analysis.missingExamFindings?.length || 0) > 0;

    if (hasDifferentials && hasIcd10 && hasPatientSummary && hasMissingHistory && hasMissingExam) {
      results.push({ name: 'Clinical Decision Heuristics: Complete Multi-Domain Analysis', passed: true });
    } else {
      results.push({
        name: 'Clinical Decision Heuristics: Complete Multi-Domain Analysis',
        passed: false,
        details: `Incomplete analysis output: diffs=${hasDifferentials}, icd10=${hasIcd10}, summary=${hasPatientSummary}, historyGaps=${hasMissingHistory}, examGaps=${hasMissingExam}`,
      });
    }
  } catch (err: any) {
    results.push({ name: 'Clinical Decision Heuristics', passed: false, details: err.message });
  }

  // Test 4: Pediatric Otitis Media Heuristics
  try {
    const pedsCase = CLINICAL_CASES[1];
    const analysis = runHeuristicClinicalAnalysis(pedsCase.initialNote, pedsCase.patient);

    const mentionsAom = analysis.differentials.some(
      (d) => d.diagnosis.toLowerCase().includes('otitis media') || d.icd10.includes('H66')
    );
    const detectsPenicillinRisk = analysis.safetyAlerts.some(
      (a) => a.type === 'allergy' || a.title.toLowerCase().includes('penicillin')
    );

    if (mentionsAom && detectsPenicillinRisk) {
      results.push({ name: 'Pediatric Case: AOM Differential & Allergy Risk Synthesis', passed: true });
    } else {
      results.push({
        name: 'Pediatric Case: AOM Differential & Allergy Risk Synthesis',
        passed: false,
        details: `Expected AOM differential and penicillin allergy alert: aom=${mentionsAom}, allergy=${detectsPenicillinRisk}`,
      });
    }
  } catch (err: any) {
    results.push({ name: 'Pediatric Case Heuristics', passed: false, details: err.message });
  }

  return results;
}
