import { maskPhiInText, maskPatientDemographics } from '../src/utils/dataMasker';
import { logAuditEvent, getAuditLog } from '../src/utils/auditLogger';
import { CLINICAL_CASES } from '../src/data/clinicalTemplates';

export function runDataMaskerAndAuditTests(): { name: string; passed: boolean; details?: string }[] {
  const results: { name: string; passed: boolean; details?: string }[] = [];

  const samplePatient = CLINICAL_CASES[0].patient;

  // Test 1: PHI Demographics Masking
  try {
    const masked = maskPatientDemographics(samplePatient);

    const nameMasked = masked.name.includes('[REDACTED') || masked.name !== samplePatient.name;
    const mrnMasked = masked.mrn.includes('[MRN-') || masked.mrn !== samplePatient.mrn;

    if (nameMasked && mrnMasked) {
      results.push({ name: 'HIPAA Safe Harbor: Patient Demographics PHI Masked', passed: true });
    } else {
      results.push({
        name: 'HIPAA Safe Harbor: Patient Demographics PHI Masked',
        passed: false,
        details: `Name or MRN was not properly masked: name=${masked.name}, mrn=${masked.mrn}`,
      });
    }
  } catch (err: any) {
    results.push({ name: 'HIPAA Safe Harbor Masking', passed: false, details: err.message });
  }

  // Test 2: Free Text PHI Masking
  try {
    const rawText = `Patient John Doe (DOB: 1980-05-12, SSN: 123-45-6789, Phone: 555-123-4567, MRN-998877) was admitted on 2026-10-15.`;
    const masked = maskPhiInText(rawText);

    const hasSsn = masked.includes('123-45-6789');
    const hasPhone = masked.includes('555-123-4567');
    const hasMrn = masked.includes('MRN-998877');

    if (!hasSsn && !hasPhone && !hasMrn) {
      results.push({ name: 'Free-Text PHI Sanitization (SSN, Phone, MRN Redaction)', passed: true });
    } else {
      results.push({
        name: 'Free-Text PHI Sanitization (SSN, Phone, MRN Redaction)',
        passed: false,
        details: `Failed to redact identifiers from text: ssn=${hasSsn}, phone=${hasPhone}, mrn=${hasMrn}`,
      });
    }
  } catch (err: any) {
    results.push({ name: 'Free-Text PHI Sanitization', passed: false, details: err.message });
  }

  // Test 3: Tamper-Evident Audit Logging
  try {
    const initialLogCount = getAuditLog().length;
    logAuditEvent({
      userId: 'usr-test-1',
      userName: 'Dr. Automated Tester',
      role: 'doctor',
      action: 'SIGN_NOTE',
      patientMrn: 'MRN-999999',
      patientName: 'Test Patient',
      details: 'Audit logging automated unit test verification entry.',
    });

    const updatedLog = getAuditLog();
    const latestEntry = updatedLog[0];

    const countIncremented = updatedLog.length > initialLogCount;
    const hasCorrectAction = latestEntry?.action === 'SIGN_NOTE';
    const hasTimestamp = Boolean(latestEntry?.timestamp);

    if (countIncremented && hasCorrectAction && hasTimestamp) {
      results.push({ name: 'HIPAA Audit Trail: Event Recorded & Serialized Correctly', passed: true });
    } else {
      results.push({
        name: 'HIPAA Audit Trail: Event Recorded & Serialized Correctly',
        passed: false,
        details: `Audit log verification failed: countIncr=${countIncremented}, action=${latestEntry?.action}`,
      });
    }
  } catch (err: any) {
    results.push({ name: 'HIPAA Audit Trail Logging', passed: false, details: err.message });
  }

  return results;
}
