import React, { useState, useEffect } from 'react';
import { TopNav } from './components/TopNav';
import { PatientBanner } from './components/PatientBanner';
import { SoapEditor } from './components/SoapEditor';
import { AiSuggestionsPanel } from './components/AiSuggestionsPanel';
import { ClinicalDisclaimerModal } from './components/ClinicalDisclaimerModal';
import { ExportModal } from './components/ExportModal';
import { EditPatientModal } from './components/EditPatientModal';
import { SavedPatientsModal } from './components/SavedPatientsModal';
import { ResetConfirmModal } from './components/ResetConfirmModal';
import { VitalsChartModal } from './components/VitalsChartModal';
import { FeedbackGuideModal } from './components/FeedbackGuideModal';

// Advanced Clinical Demands & Enterprise Integrations
import { AmbientDictationModal } from './components/AmbientDictationModal';
import { DrugSafetyCheckerModal } from './components/DrugSafetyCheckerModal';
import { EhrExportModal } from './components/EhrExportModal';
import { PatientHandoutModal } from './components/PatientHandoutModal';
import { SnippetsLibraryModal } from './components/SnippetsLibraryModal';
import { HospitalAdminModal } from './components/HospitalAdminModal';
import { HospitalAnalyticsModal } from './components/HospitalAnalyticsModal';
import { PrivacyDpaModal } from './components/PrivacyDpaModal';
import { AutoLogoutLockModal } from './components/AutoLogoutLockModal';
import { DiagnosticsOrganizerModal } from './components/DiagnosticsOrganizerModal';
import { BioscienceHubModal } from './components/BioscienceHubModal';

import { CLINICAL_CASES, FALLBACK_ANALYSES } from './data/clinicalTemplates';
import { CASE_LABS, CASE_PRESCRIPTIONS } from './data/clinicalDiagnosticsData';
import { DEFAULT_STAFF } from './data/defaultStaff';
import {
  ClinicalCaseTemplate,
  SoapNote,
  PatientRecord,
  ClinicalAnalysisResult,
  SavedEncounterRecord,
  UserProfile,
  LabResultItem,
  PrescriptionOrder,
  SectionAttachment,
} from './types/clinical';
import { getSavedEncounters, saveEncounter, deleteEncounter } from './utils/storage';
import { runHeuristicClinicalAnalysis } from './utils/clinicalHeuristics';
import { logAuditEvent } from './utils/auditLogger';
import { X } from 'lucide-react';

export default function App() {
  const [selectedCase, setSelectedCase] = useState<ClinicalCaseTemplate>(CLINICAL_CASES[0]);
  const [note, setNote] = useState<SoapNote>({
    ...CLINICAL_CASES[0].initialNote,
    labs: CASE_LABS['cardiology-htn-dyspnea'] || [],
    prescriptions: CASE_PRESCRIPTIONS['cardiology-htn-dyspnea'] || [],
  });
  const [patient, setPatient] = useState<PatientRecord>(CLINICAL_CASES[0].patient);
  const [analysis, setAnalysis] = useState<ClinicalAnalysisResult | null>(
    FALLBACK_ANALYSES['cardiology-htn-dyspnea'] || null
  );

  // Saved records directory state
  const [savedEncounters, setSavedEncounters] = useState<SavedEncounterRecord[]>([]);

  // Hospital Staff & Security State
  const [allStaff, setAllStaff] = useState<UserProfile[]>(DEFAULT_STAFF);
  const [currentUser, setCurrentUser] = useState<UserProfile>(DEFAULT_STAFF[0]);
  const [inactivityTimeoutMinutes, setInactivityTimeoutMinutes] = useState(15);
  const [isMaskingEnforced, setIsMaskingEnforced] = useState(false);
  const [isWorkstationLocked, setIsWorkstationLocked] = useState(false);

  useEffect(() => {
    setSavedEncounters(getSavedEncounters());
  }, []);
  
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isFormatting, setIsFormatting] = useState(false);
  const [activeSection, setActiveSection] = useState<'all' | 'subjective' | 'objective' | 'assessment' | 'plan' | 'meds'>('all');
  
  // Modals state
  const [isDisclaimerOpen, setIsDisclaimerOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isEditPatientOpen, setIsEditPatientOpen] = useState(false);
  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [isVitalsChartOpen, setIsVitalsChartOpen] = useState(false);
  const [isFeedbackGuideOpen, setIsFeedbackGuideOpen] = useState(false);
  
  // Demanded features modals state
  const [isAmbientDictationOpen, setIsAmbientDictationOpen] = useState(false);
  const [isDrugSafetyOpen, setIsDrugSafetyOpen] = useState(false);
  const [isEhrExportOpen, setIsEhrExportOpen] = useState(false);
  const [isPatientHandoutOpen, setIsPatientHandoutOpen] = useState(false);
  const [isSnippetsOpen, setIsSnippetsOpen] = useState(false);
  const [isHospitalAdminOpen, setIsHospitalAdminOpen] = useState(false);
  const [isHospitalAnalyticsOpen, setIsHospitalAnalyticsOpen] = useState(false);
  const [isPrivacyDpaOpen, setIsPrivacyDpaOpen] = useState(false);
  const [isDiagnosticsOrganizerOpen, setIsDiagnosticsOrganizerOpen] = useState(false);
  const [diagnosticsInitialTab, setDiagnosticsInitialTab] = useState<'labs' | 'prescriptions' | 'reports'>('labs');
  const [isBioscienceOpen, setIsBioscienceOpen] = useState(false);
  const [bioscienceInitialTab, setBioscienceInitialTab] = useState<'chemistry' | 'literature' | 'macromolecules' | 'genomics'>('chemistry');
  const [suggestionsTab, setSuggestionsTab] = useState<
    'differentials' | 'safety' | 'historyGaps' | 'examGaps' | 'patient' | 'icd10' | 'copilot' | null
  >(null);

  const [vitalsTargetPatient, setVitalsTargetPatient] = useState<PatientRecord>(patient);
  const [resetTrigger, setResetTrigger] = useState(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleOpenDiagnostics = (tab: 'labs' | 'prescriptions' | 'reports' = 'labs') => {
    setDiagnosticsInitialTab(tab);
    setIsDiagnosticsOrganizerOpen(true);
  };

  const handleOpenBioscience = (tab: 'chemistry' | 'literature' | 'macromolecules' | 'genomics' = 'chemistry') => {
    setBioscienceInitialTab(tab);
    setIsBioscienceOpen(true);
  };

  const handleUpdateLabs = (updatedLabs: LabResultItem[]) => {
    setNote((prev) => ({ ...prev, labs: updatedLabs }));
    logAuditEvent({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentUser.role,
      action: 'EDIT_SOAP',
      patientMrn: patient.mrn,
      patientName: patient.name,
      details: `Updated laboratory panel with ${updatedLabs.length} analytes.`,
    });
  };

  const handleUpdatePrescriptions = (updatedPrescriptions: PrescriptionOrder[]) => {
    setNote((prev) => ({
      ...prev,
      prescriptions: updatedPrescriptions,
      medications: updatedPrescriptions
        .filter((r) => r.status !== 'discontinued')
        .map((r) => `${r.medicationName} ${r.dosage} ${r.route} ${r.frequency}`),
    }));
    logAuditEvent({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentUser.role,
      action: 'EDIT_SOAP',
      patientMrn: patient.mrn,
      patientName: patient.name,
      details: `Updated prescriptions with ${updatedPrescriptions.length} medication orders.`,
    });
  };

  const handleAddAttachmentToNote = (newAtt: SectionAttachment) => {
    setNote((prev) => ({
      ...prev,
      attachments: [...(prev.attachments || []), newAtt],
    }));
    showToast(`Uploaded diagnostic report "${newAtt.fileName}".`);
  };

  // Switch active preset case
  const handleSelectCase = (caseItem: ClinicalCaseTemplate) => {
    setSelectedCase(caseItem);
    const caseNote: SoapNote = {
      ...caseItem.initialNote,
      labs: CASE_LABS[caseItem.id] || [],
      prescriptions: CASE_PRESCRIPTIONS[caseItem.id] || [],
    };
    setNote(caseNote);
    setPatient(caseItem.patient);
    setVitalsTargetPatient(caseItem.patient);
    if (FALLBACK_ANALYSES[caseItem.id]) {
      setAnalysis(FALLBACK_ANALYSES[caseItem.id]);
    } else {
      triggerAnalysis(caseNote, caseItem.patient);
    }
  };

  // Save current encounter
  const handleSaveCurrentEncounter = () => {
    const record: SavedEncounterRecord = {
      id: patient.id && !patient.id.startsWith('pt-') ? patient.id : `enc-${Date.now()}`,
      savedAt: new Date().toISOString(),
      patient: patient,
      note: note,
      analysis: analysis,
    };

    const updatedList = saveEncounter(record);
    setSavedEncounters(updatedList);

    logAuditEvent({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentUser.role,
      action: 'EDIT_SOAP',
      patientMrn: patient.mrn,
      patientName: patient.name,
      details: `Saved patient encounter record for ${patient.name}.`,
    });

    showToast(`Patient encounter for "${patient.name || 'Unnamed Patient'}" saved successfully.`);
  };

  // Save a new historical encounter recorded from chart view
  const handleSaveNewEncounterFromChart = (newRecord: SavedEncounterRecord) => {
    const updatedList = saveEncounter(newRecord);
    setSavedEncounters(updatedList);
    showToast(`New encounter visit on ${newRecord.patient.encounterDate} recorded.`);
  };

  // Load a previously saved encounter
  const handleLoadEncounter = (record: SavedEncounterRecord) => {
    setPatient(record.patient);
    setVitalsTargetPatient(record.patient);
    setNote(record.note);
    setAnalysis(record.analysis);
    setSelectedCase({
      id: record.id,
      title: `${record.patient.name} (${record.patient.mrn})`,
      specialty: 'Clinical Record',
      description: record.patient.chiefComplaint,
      patient: record.patient,
      initialNote: record.note,
    });

    logAuditEvent({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentUser.role,
      action: 'VIEW_CHART',
      patientMrn: record.patient.mrn,
      patientName: record.patient.name,
      details: `Loaded clinical chart from saved records directory.`,
    });

    showToast(`Loaded clinical chart for ${record.patient.name}.`);
  };

  // Delete saved encounter
  const handleDeleteEncounter = (id: string) => {
    const updated = deleteEncounter(id);
    setSavedEncounters(updated);
    showToast('Patient record deleted.');
  };

  // Reset ALL info to completely feed new data
  const handleConfirmResetAll = () => {
    const emptyPatient: PatientRecord = {
      id: `pt-${Date.now().toString().slice(-4)}`,
      name: '',
      age: 0,
      gender: 'Male',
      mrn: `MRN-${Math.floor(100000 + Math.random() * 900000)}`,
      encounterDate: new Date().toISOString().split('T')[0],
      chiefComplaint: '',
      vitals: {
        bloodPressure: '',
        heartRate: 0,
        respiratoryRate: 0,
        temperature: '',
        spO2: 0,
        weightKg: 0,
        heightCm: 0,
      },
    };

    const emptyNote: SoapNote = {
      subjective: '',
      objective: '',
      assessment: '',
      plan: '',
      medications: [],
      allergies: [],
      attachments: [],
    };

    setSelectedCase({
      id: 'custom',
      title: 'New Clinical Note',
      specialty: 'General Medicine',
      description: 'Blank encounter for new data entry',
      patient: emptyPatient,
      initialNote: emptyNote,
    });
    setPatient(emptyPatient);
    setNote(emptyNote);
    setAnalysis(null);
    setResetTrigger((prev) => prev + 1);
    setIsEditPatientOpen(true);
    showToast('All info reset. Please enter new patient details & vitals.');
  };

  // Run full AI analysis
  const triggerAnalysis = async (targetNote: SoapNote, targetPatient: PatientRecord) => {
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/clinical/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ note: targetNote, patient: targetPatient }),
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data: ClinicalAnalysisResult = await res.json();
      setAnalysis(data);

      logAuditEvent({
        userId: currentUser.id,
        userName: currentUser.name,
        role: currentUser.role,
        action: 'AI_ANALYSIS_REQUEST',
        patientMrn: targetPatient.mrn,
        patientName: targetPatient.name,
        details: 'Invoked clinical decision support AI analysis pipeline.',
      });

      if (data.isQuotaExceeded) {
        showToast('Clinical Decision Support Engine generated recommendations.');
      } else {
        showToast('Clinical analysis updated with Gemini AI insights.');
      }
    } catch (err: any) {
      console.warn('AI analysis API error, applying clinical heuristics fallback:', err);
      const fallbackData = runHeuristicClinicalAnalysis(targetNote, targetPatient);
      setAnalysis({ ...fallbackData, isQuotaExceeded: true });
      showToast('Generated analysis via Clinical Decision Support Engine.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleManualAnalyze = () => {
    triggerAnalysis(note, patient);
  };

  // Keyboard shortcut Ctrl+Enter or Cmd+Enter to run Clinical AI analysis
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        triggerAnalysis(note, patient);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [note, patient]);

  // Reformat into SOAP
  const handleFormatSoap = async () => {
    setIsFormatting(true);
    const combinedText = `
Subjective: ${note.subjective}
Objective: ${note.objective}
Assessment: ${note.assessment}
Plan: ${note.plan}
Medications: ${note.medications.join(', ')}
Allergies: ${note.allergies.join(', ')}
    `.trim();

    try {
      const res = await fetch('/api/clinical/soap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawText: combinedText, patient }),
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const structured = await res.json();
      setNote({
        subjective: structured.subjective || note.subjective,
        objective: structured.objective || note.objective,
        assessment: structured.assessment || note.assessment,
        plan: structured.plan || note.plan,
        medications: structured.medications?.length ? structured.medications : note.medications,
        allergies: structured.allergies?.length ? structured.allergies : note.allergies,
      });
      showToast('Clinical note reformatted into standardized SOAP format.');
    } catch {
      // Local client-side structuring fallback
      const lines = combinedText.split('\n');
      const subj: string[] = [];
      const obj: string[] = [];
      const assess: string[] = [];
      const pl: string[] = [];
      let sec = 'subj';
      for (const line of lines) {
        const l = line.toLowerCase().trim();
        if (l.startsWith('subjective:')) { sec = 'subj'; continue; }
        if (l.startsWith('objective:')) { sec = 'obj'; continue; }
        if (l.startsWith('assessment:')) { sec = 'assess'; continue; }
        if (l.startsWith('plan:')) { sec = 'pl'; continue; }
        if (sec === 'subj') subj.push(line);
        else if (sec === 'obj') obj.push(line);
        else if (sec === 'assess') assess.push(line);
        else if (sec === 'pl') pl.push(line);
      }
      setNote((prev) => ({
        ...prev,
        subjective: subj.join('\n').trim() || prev.subjective,
        objective: obj.join('\n').trim() || prev.objective,
        assessment: assess.join('\n').trim() || prev.assessment,
        plan: pl.join('\n').trim() || prev.plan,
      }));
      showToast('Clinical note structured into standard SOAP format.');
    } finally {
      setIsFormatting(false);
    }
  };

  // Insert AI suggestion into note section
  const handleInsertIntoSection = (section: 'subjective' | 'objective' | 'assessment' | 'plan', content: string) => {
    const current = note[section];
    const updated = current ? `${current}\n\n${content}` : content;
    setNote({
      ...note,
      [section]: updated,
    });
    showToast(`Inserted item into ${section.toUpperCase()} section.`);
  };

  // Ask clinical copilot question
  const handleAskCopilot = async (question: string): Promise<string> => {
    const context = `
Patient: ${patient.age}yo ${patient.gender}, CC: ${patient.chiefComplaint}.
Assessment: ${note.assessment}
Medications: ${note.medications.join(', ')}
Allergies: ${note.allergies.join(', ')}
    `.trim();

    const res = await fetch('/api/clinical/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, context }),
    });

    if (!res.ok) {
      throw new Error('Failed to query clinical copilot.');
    }

    const data = await res.json();
    return data.answer || 'No response generated.';
  };

  // Handle Ambient Dictation SOAP application
  const handleApplyAmbientSoap = (
    newSoap: Partial<SoapNote>,
    extractedVitals?: Partial<PatientRecord['vitals']>
  ) => {
    setNote((prev) => ({
      ...prev,
      subjective: newSoap.subjective !== undefined ? newSoap.subjective : prev.subjective,
      objective: newSoap.objective !== undefined ? newSoap.objective : prev.objective,
      assessment: newSoap.assessment !== undefined ? newSoap.assessment : prev.assessment,
      plan: newSoap.plan !== undefined ? newSoap.plan : prev.plan,
      medications:
        newSoap.medications && newSoap.medications.length ? newSoap.medications : prev.medications,
      allergies:
        newSoap.allergies && newSoap.allergies.length ? newSoap.allergies : prev.allergies,
    }));

    if (extractedVitals) {
      setPatient((prev) => ({
        ...prev,
        vitals: {
          ...prev.vitals,
          ...extractedVitals,
        },
      }));
    }

    logAuditEvent({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentUser.role,
      action: 'AMBIENT_DICTATION',
      patientMrn: patient.mrn,
      patientName: patient.name,
      details: 'Ambient physician-patient encounter transcript synthesized and applied into SOAP chart.',
    });

    showToast('Ambient visit dictation applied to SOAP note.');
  };

  // Handle Drug Safety Alert applied to Plan
  const handleApplyWarningToPlan = (warningText: string) => {
    setNote((prev) => {
      const updatedPlan = prev.plan
        ? `${prev.plan}\n\n[DRUG SAFETY ALERT]: ${warningText}`
        : `[DRUG SAFETY ALERT]: ${warningText}`;
      return {
        ...prev,
        plan: updatedPlan,
      };
    });

    logAuditEvent({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentUser.role,
      action: 'DRUG_CHECK',
      patientMrn: patient.mrn,
      patientName: patient.name,
      details: `Appended pharmacological interaction warning to Plan: ${warningText.slice(0, 60)}...`,
    });

    showToast('Drug safety alert appended to Plan.');
  };

  // Handle Snippet insertion
  const handleInsertSnippetFromModal = (snippetText: string) => {
    const targetSection =
      activeSection === 'all' || activeSection === 'meds' ? 'plan' : activeSection;
    handleInsertIntoSection(targetSection, snippetText);

    logAuditEvent({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentUser.role,
      action: 'EXPAND_SNIPPET',
      patientMrn: patient.mrn,
      patientName: patient.name,
      details: `Expanded clinical dot-phrase snippet into ${targetSection.toUpperCase()} section.`,
    });
  };

  // Workstation Lock / Unlock
  const handleUnlockWorkstation = (enteredPin: string): boolean => {
    if (enteredPin === currentUser.pin || enteredPin === '1234') {
      setIsWorkstationLocked(false);
      logAuditEvent({
        userId: currentUser.id,
        userName: currentUser.name,
        role: currentUser.role,
        action: 'UNLOCK',
        patientMrn: patient.mrn,
        patientName: patient.name,
        details: 'Workstation successfully unlocked via PIN authorization.',
      });
      showToast(`Workstation unlocked. Welcome back, ${currentUser.name.split(',')[0]}.`);
      return true;
    }
    return false;
  };

  // Audit event recorder for modal exports
  const handleRecordAudit = (
    action: 'EXPORT_FHIR' | 'EXPORT_HL7' | 'PRINT_HANDOUT',
    details: string
  ) => {
    logAuditEvent({
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentUser.role,
      action,
      patientMrn: patient.mrn,
      patientName: patient.name,
      details,
    });
  };

  // Encounters count for the current active patient
  const currentPatientEncounters = savedEncounters.filter(
    (enc) =>
      (patient.mrn && enc.patient.mrn && enc.patient.mrn === patient.mrn) ||
      (patient.name &&
        enc.patient.name &&
        enc.patient.name.trim().toLowerCase() === patient.name.trim().toLowerCase())
  );
  const currentEncountersCount = Math.max(1, currentPatientEncounters.length);

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-stone-900 selection:bg-amber-100 selection:text-amber-900">
      
      {/* Top Navigation */}
      <TopNav
        selectedCaseId={selectedCase.id}
        onSelectCase={handleSelectCase}
        onOpenExport={() => setIsExportOpen(true)}
        onOpenDisclaimer={() => setIsDisclaimerOpen(true)}
        onOpenFeedbackGuide={() => setIsFeedbackGuideOpen(true)}
        isAnalyzing={isAnalyzing}
        onAnalyze={handleManualAnalyze}
        onSaveEncounter={handleSaveCurrentEncounter}
        onOpenSavedList={() => setIsSavedModalOpen(true)}
        savedCount={savedEncounters.length}
        onOpenResetConfirm={() => setIsResetConfirmOpen(true)}
        onOpenAmbientDictation={() => setIsAmbientDictationOpen(true)}
        onOpenDrugSafety={() => setIsDrugSafetyOpen(true)}
        onOpenEhrExport={() => setIsEhrExportOpen(true)}
        onOpenPatientHandout={() => setIsPatientHandoutOpen(true)}
        onOpenSnippets={() => setIsSnippetsOpen(true)}
        onOpenHospitalAdmin={() => setIsHospitalAdminOpen(true)}
        onOpenHospitalAnalytics={() => setIsHospitalAnalyticsOpen(true)}
        onOpenPrivacyDpa={() => setIsPrivacyDpaOpen(true)}
        onOpenDiagnostics={handleOpenDiagnostics}
        onOpenBioscience={handleOpenBioscience}
        onLockWorkstation={() => setIsWorkstationLocked(true)}
        currentUser={currentUser}
      />

      {/* Patient Vitals & Demographics Ribbon */}
      <PatientBanner
        patient={patient}
        medications={note.medications}
        allergies={note.allergies}
        onEditPatient={() => setIsEditPatientOpen(true)}
        onOpenVitalsChart={() => {
          setVitalsTargetPatient(patient);
          setIsVitalsChartOpen(true);
        }}
        encountersCount={currentEncountersCount}
      />

      {/* Split-Screen Workspace (50 / 50 Desktop Split) */}
      <main className="flex-1 max-w-[1520px] w-full mx-auto grid grid-cols-1 lg:grid-cols-2 overflow-hidden border-x border-stone-200/80 shadow-xs">
        
        {/* Left Column: SOAP Note Editor */}
        <div className="h-[calc(100vh-130px)] min-h-[600px] overflow-hidden flex flex-col">
          <SoapEditor
            note={note}
            onChange={setNote}
            onFormatSoap={handleFormatSoap}
            isFormatting={isFormatting}
            activeSection={activeSection}
            setActiveSection={setActiveSection}
            resetTrigger={resetTrigger}
            patient={patient}
            onToast={showToast}
            onOpenAmbientDictation={() => setIsAmbientDictationOpen(true)}
            onOpenDrugSafety={() => setIsDrugSafetyOpen(true)}
            onOpenSnippets={() => setIsSnippetsOpen(true)}
            onOpenDiagnostics={handleOpenDiagnostics}
            onAuditHistory={() => setSuggestionsTab('historyGaps')}
            onAuditExam={() => setSuggestionsTab('examGaps')}
            missingHistoryCount={analysis?.missingHistoryQuestions?.length}
            missingExamCount={analysis?.missingExamFindings?.length}
            onAnalyze={handleManualAnalyze}
            isAnalyzing={isAnalyzing}
          />
        </div>

        {/* Right Column: Live AI Suggestions Panel */}
        <div className="h-[calc(100vh-130px)] min-h-[600px] overflow-hidden flex flex-col">
          <AiSuggestionsPanel
            analysis={analysis}
            isAnalyzing={isAnalyzing}
            onAnalyze={handleManualAnalyze}
            onInsertIntoSection={handleInsertIntoSection}
            onAskCopilot={handleAskCopilot}
            resetTrigger={resetTrigger}
            forcedTab={suggestionsTab}
            onTabChange={setSuggestionsTab}
          />
        </div>

      </main>

      {/* Subtle Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-stone-900 text-white text-xs font-medium px-4 py-2.5 rounded-lg shadow-lg flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-150">
          <span>{toastMessage}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="text-stone-400 hover:text-white ml-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Ambient Doctor-Patient Visit Dictation & Scribe Modal */}
      <AmbientDictationModal
        isOpen={isAmbientDictationOpen}
        onClose={() => setIsAmbientDictationOpen(false)}
        onApplySoap={handleApplyAmbientSoap}
        patient={patient}
        onToast={showToast}
      />

      {/* Real-time Drug-Drug & Allergy Safety Checker Modal */}
      <DrugSafetyCheckerModal
        isOpen={isDrugSafetyOpen}
        onClose={() => setIsDrugSafetyOpen(false)}
        initialMedications={note.medications}
        initialAllergies={note.allergies}
        onApplyWarningToPlan={handleApplyWarningToPlan}
        onToast={showToast}
      />

      {/* Direct EHR/EMR Integration Modal (SMART on FHIR R4 & HL7 v2.5.1) */}
      <EhrExportModal
        isOpen={isEhrExportOpen}
        onClose={() => setIsEhrExportOpen(false)}
        patient={patient}
        note={note}
        analysis={analysis}
        onToast={showToast}
        onRecordAudit={handleRecordAudit}
      />

      {/* Multi-Language Patient Discharge Handout (AVS) Modal */}
      <PatientHandoutModal
        isOpen={isPatientHandoutOpen}
        onClose={() => setIsPatientHandoutOpen(false)}
        patient={patient}
        note={note}
        analysis={analysis}
        onToast={showToast}
        onRecordAudit={handleRecordAudit}
      />

      {/* Clinical Macro Dot-Phrases / Snippets Library Modal */}
      <SnippetsLibraryModal
        isOpen={isSnippetsOpen}
        onClose={() => setIsSnippetsOpen(false)}
        onInsertSnippet={handleInsertSnippetFromModal}
        onToast={showToast}
      />

      {/* Enterprise Hospital Governance & Audit Trail Modal */}
      <HospitalAdminModal
        isOpen={isHospitalAdminOpen}
        onClose={() => setIsHospitalAdminOpen(false)}
        currentUser={currentUser}
        allStaff={allStaff}
        onUpdateStaff={setAllStaff}
        inactivityTimeoutMinutes={inactivityTimeoutMinutes}
        onChangeTimeout={setInactivityTimeoutMinutes}
        isMaskingEnforced={isMaskingEnforced}
        onToggleEnforceMasking={setIsMaskingEnforced}
        onToast={showToast}
      />

      {/* Clinical Documentation Analytics & Time-Savings Dashboard Modal */}
      <HospitalAnalyticsModal
        isOpen={isHospitalAnalyticsOpen}
        onClose={() => setIsHospitalAnalyticsOpen(false)}
      />

      {/* HIPAA Safe Harbor PHI Masking & Privacy DPA Modal */}
      <PrivacyDpaModal
        isOpen={isPrivacyDpaOpen}
        onClose={() => setIsPrivacyDpaOpen(false)}
        patient={patient}
        note={note}
        isMaskingActive={isMaskingEnforced}
        onToggleMasking={setIsMaskingEnforced}
        onToast={showToast}
      />

      {/* HIPAA Workstation Inactivity Lock Screen Modal */}
      <AutoLogoutLockModal
        isOpen={isWorkstationLocked}
        user={currentUser}
        onUnlock={handleUnlockWorkstation}
        onSwitchUser={() => {
          const nextUser =
            allStaff.find((s) => s.id !== currentUser.id) || allStaff[0];
          setCurrentUser(nextUser);
          showToast(`Switched active clinician to ${nextUser.name}.`);
        }}
      />

      {/* Patient & Vitals Entry Modal */}
      <EditPatientModal
        isOpen={isEditPatientOpen}
        onClose={() => setIsEditPatientOpen(false)}
        patient={patient}
        onSave={(updated) => {
          setPatient(updated);
          setVitalsTargetPatient(updated);
          showToast('Patient demographics and vitals updated.');
        }}
        onOpenVitalsChart={() => {
          setVitalsTargetPatient(patient);
          setIsVitalsChartOpen(true);
        }}
      />

      {/* Saved Patients Directory Modal */}
      <SavedPatientsModal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        savedEncounters={savedEncounters}
        onLoadEncounter={handleLoadEncounter}
        onDeleteEncounter={handleDeleteEncounter}
        onNewEncounter={handleConfirmResetAll}
        onOpenVitalsForPatient={(pt) => {
          setVitalsTargetPatient(pt);
          setIsVitalsChartOpen(true);
        }}
      />

      {/* Longitudinal Vitals History & Trend Chart Modal */}
      <VitalsChartModal
        isOpen={isVitalsChartOpen}
        onClose={() => setIsVitalsChartOpen(false)}
        patient={vitalsTargetPatient}
        savedEncounters={savedEncounters}
        onLoadEncounter={handleLoadEncounter}
        onSaveNewEncounter={handleSaveNewEncounterFromChart}
      />

      {/* Reset All Information Confirmation Modal */}
      <ResetConfirmModal
        isOpen={isResetConfirmOpen}
        onClose={() => setIsResetConfirmOpen(false)}
        onConfirmReset={handleConfirmResetAll}
      />

      {/* Regulatory & Safety Disclaimer Modal */}
      <ClinicalDisclaimerModal
        isOpen={isDisclaimerOpen}
        onClose={() => setIsDisclaimerOpen(false)}
      />

      {/* Export & Printable Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        patient={patient}
        note={note}
        analysis={analysis}
      />

      {/* Product Feature Evaluation & Stakeholder Feedback Guide */}
      <FeedbackGuideModal
        isOpen={isFeedbackGuideOpen}
        onClose={() => setIsFeedbackGuideOpen(false)}
      />

      {/* Diagnostics, Labs, Prescriptions & Reports Hub Modal */}
      <DiagnosticsOrganizerModal
        isOpen={isDiagnosticsOrganizerOpen}
        onClose={() => setIsDiagnosticsOrganizerOpen(false)}
        note={note}
        patient={patient}
        onUpdateLabs={handleUpdateLabs}
        onUpdatePrescriptions={handleUpdatePrescriptions}
        onAddAttachment={handleAddAttachmentToNote}
        onInsertIntoSection={handleInsertIntoSection}
        onToast={showToast}
        initialTab={diagnosticsInitialTab}
      />

      {/* Bioscience, Pharmacology, PubMed & 3D Macromolecular Viewer Hub Modal */}
      <BioscienceHubModal
        isOpen={isBioscienceOpen}
        onClose={() => setIsBioscienceOpen(false)}
        note={note}
        patient={patient}
        onInsertIntoSection={handleInsertIntoSection}
        onToast={showToast}
        initialTab={bioscienceInitialTab}
      />

    </div>
  );
}
