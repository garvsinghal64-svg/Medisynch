import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  AlertTriangle,
  Stethoscope,
  HeartPulse,
  BookOpen,
  Send,
  Plus,
  Check,
  Copy,
  Info,
  ShieldCheck,
  RotateCcw,
  HelpCircle,
  Activity,
  ClipboardCheck,
  ListTodo,
  CheckSquare,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { ClinicalAnalysisResult, ClinicalDifferential, DrugSafetyAlert, Icd10Suggestion } from '../types/clinical';

interface AiSuggestionsPanelProps {
  analysis: ClinicalAnalysisResult | null;
  isAnalyzing: boolean;
  onAnalyze: () => void;
  onInsertIntoSection: (section: 'subjective' | 'objective' | 'assessment' | 'plan', content: string) => void;
  onAskCopilot: (question: string) => Promise<string>;
  resetTrigger?: number;
  forcedTab?: 'differentials' | 'safety' | 'historyGaps' | 'examGaps' | 'patient' | 'icd10' | 'copilot' | null;
  onTabChange?: (tab: 'differentials' | 'safety' | 'historyGaps' | 'examGaps' | 'patient' | 'icd10' | 'copilot') => void;
}

export const AiSuggestionsPanel: React.FC<AiSuggestionsPanelProps> = ({
  analysis,
  isAnalyzing,
  onAnalyze,
  onInsertIntoSection,
  onAskCopilot,
  resetTrigger,
  forcedTab,
  onTabChange,
}) => {
  const [activeTab, setActiveTab] = useState<
    'differentials' | 'safety' | 'historyGaps' | 'examGaps' | 'patient' | 'icd10' | 'copilot'
  >('differentials');
  const [questionStatuses, setQuestionStatuses] = useState<Record<string, 'unasked' | 'asked_negative' | 'asked_positive'>>({});
  const [examStatuses, setExamStatuses] = useState<Record<string, 'unexamined' | 'normal' | 'abnormal'>>({});
  const [copilotQuestion, setCopilotQuestion] = useState('');
  const [copilotAnswer, setCopilotAnswer] = useState<string | null>(null);
  const [isCopilotLoading, setIsCopilotLoading] = useState(false);
  const [copiedPatientSummary, setCopiedPatientSummary] = useState(false);
  const [insertedItems, setInsertedItems] = useState<Record<string, boolean>>({});

  const handleSelectTab = (tab: 'differentials' | 'safety' | 'historyGaps' | 'examGaps' | 'patient' | 'icd10' | 'copilot') => {
    setActiveTab(tab);
    if (onTabChange) onTabChange(tab);
  };

  useEffect(() => {
    if (forcedTab) {
      setActiveTab(forcedTab);
    }
  }, [forcedTab]);

  // Reset internal guidelines question, answer, and tab when resetTrigger triggers or analysis is cleared
  useEffect(() => {
    setCopilotQuestion('');
    setCopilotAnswer(null);
    setInsertedItems({});
    setActiveTab('differentials');
  }, [resetTrigger]);

  useEffect(() => {
    if (analysis === null) {
      setCopilotQuestion('');
      setCopilotAnswer(null);
      setInsertedItems({});
    }
  }, [analysis]);

  const markInserted = (key: string) => {
    setInsertedItems((prev) => ({ ...prev, [key]: true }));
    setTimeout(() => {
      setInsertedItems((prev) => ({ ...prev, [key]: false }));
    }, 2000);
  };

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!copilotQuestion.trim() || isCopilotLoading) return;

    setIsCopilotLoading(true);
    setCopilotAnswer(null);
    try {
      const res = await onAskCopilot(copilotQuestion);
      setCopilotAnswer(res);
    } catch (err) {
      setCopilotAnswer('Failed to retrieve clinical response. Please try again.');
    } finally {
      setIsCopilotLoading(false);
    }
  };

  const handleCopyPatientSummary = () => {
    if (!analysis?.patientSummary) return;
    const ps = analysis.patientSummary;
    const text = `${ps.headline}
=============================

${ps.plainLanguageOverview}

KEY INSTRUCTIONS:
${ps.keyInstructions.map((inst, i) => `${i + 1}. ${inst}`).join('\n')}

MEDICATION INSTRUCTIONS:
${ps.medicationSchedule.map((m) => `• ${m.name}: ${m.instructions} (Purpose: ${m.purpose})`).join('\n')}

RED FLAG SYMPTOMS TO SEEK IMMEDIATE CARE:
${ps.redFlagSymptoms.map((rf) => `! ${rf}`).join('\n')}

FOLLOW-UP:
${ps.followUp}`;

    navigator.clipboard.writeText(text);
    setCopiedPatientSummary(true);
    setTimeout(() => setCopiedPatientSummary(false), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-[#FAF8F5]">
      
      {/* Suggestions Panel Header */}
      <div className="bg-white border-b border-stone-200/80 px-5 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-800" />
          <h2 className="text-sm font-bold text-stone-900">Clinical Intelligence Co-Pilot</h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onAnalyze}
            disabled={isAnalyzing}
            title="Analyze active SOAP note & patient vitals with Clinical Decision AI (Ctrl+Enter)"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-800 hover:bg-amber-900 text-white rounded-md text-xs font-semibold shadow-2xs transition-colors cursor-pointer disabled:opacity-50"
          >
            <Sparkles className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
            <span>{isAnalyzing ? 'Analyzing...' : 'Run Clinical AI'}</span>
          </button>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="bg-stone-50/80 border-b border-stone-200/70 px-4 py-2 flex items-center gap-1 overflow-x-auto">
        <button
          onClick={() => handleSelectTab('differentials')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'differentials'
              ? 'bg-white text-stone-900 shadow-2xs font-semibold'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <Stethoscope className="w-3.5 h-3.5 text-stone-500" />
          <span>Differentials ({analysis?.differentials.length || 0})</span>
        </button>

        <button
          onClick={() => handleSelectTab('safety')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'safety'
              ? 'bg-white text-stone-900 shadow-2xs font-semibold'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <AlertTriangle className={`w-3.5 h-3.5 ${analysis?.safetyAlerts.length ? 'text-amber-700' : 'text-stone-500'}`} />
          <span>Safety & Alerts ({analysis?.safetyAlerts.length || 0})</span>
        </button>

        <button
          onClick={() => handleSelectTab('historyGaps')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'historyGaps'
              ? 'bg-white text-stone-900 shadow-2xs font-semibold'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <HelpCircle className={`w-3.5 h-3.5 ${(analysis?.missingHistoryQuestions?.length || 0) > 0 ? 'text-blue-700' : 'text-stone-500'}`} />
          <span>Missing History ({analysis?.missingHistoryQuestions?.length || 0})</span>
        </button>

        <button
          onClick={() => handleSelectTab('examGaps')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'examGaps'
              ? 'bg-white text-stone-900 shadow-2xs font-semibold'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <ClipboardCheck className={`w-3.5 h-3.5 ${(analysis?.missingExamFindings?.length || 0) > 0 ? 'text-teal-700' : 'text-stone-500'}`} />
          <span>Missing Exam ({analysis?.missingExamFindings?.length || 0})</span>
        </button>

        <button
          onClick={() => handleSelectTab('patient')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'patient'
              ? 'bg-white text-stone-900 shadow-2xs font-semibold'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <HeartPulse className="w-3.5 h-3.5 text-rose-700" />
          <span>Patient Translation</span>
        </button>

        <button
          onClick={() => handleSelectTab('icd10')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'icd10'
              ? 'bg-white text-stone-900 shadow-2xs font-semibold'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-stone-500" />
          <span>ICD-10 ({analysis?.icd10Suggestions.length || 0})</span>
        </button>

        <button
          onClick={() => handleSelectTab('copilot')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'copilot'
              ? 'bg-white text-stone-900 shadow-2xs font-semibold'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-700" />
          <span>Ask Guidelines</span>
        </button>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 overflow-y-auto p-5">
        
        {/* Loading State Skeleton */}
        {isAnalyzing && (
          <div className="space-y-4 animate-pulse">
            <div className="h-6 bg-stone-200/70 rounded w-1/3"></div>
            <div className="bg-white rounded-lg border border-stone-200 p-4 space-y-3">
              <div className="h-4 bg-stone-200/70 rounded w-3/4"></div>
              <div className="h-3 bg-stone-100 rounded w-full"></div>
              <div className="h-3 bg-stone-100 rounded w-5/6"></div>
            </div>
            <div className="bg-white rounded-lg border border-stone-200 p-4 space-y-3">
              <div className="h-4 bg-stone-200/70 rounded w-2/3"></div>
              <div className="h-3 bg-stone-100 rounded w-full"></div>
            </div>
          </div>
        )}

        {/* Quota Exceeded Informational Notice */}
        {!isAnalyzing && analysis?.isQuotaExceeded && (
          <div className="mb-4 bg-amber-50/80 border border-amber-200/90 rounded-lg p-3 text-xs text-amber-950">
            <div className="flex items-center gap-2 font-semibold">
              <ShieldCheck className="w-4 h-4 text-amber-800 shrink-0" />
              <span>Clinical Decision Engine Active</span>
            </div>
            <p className="mt-1 text-amber-900 text-[11px] leading-relaxed">
              Gemini free-tier request quota limit was reached. CuraDoc AI engaged the evidence-based clinical rules engine to provide differentials, drug safety alerts, and patient instructions without interruption.
            </p>
          </div>
        )}

        {/* Clinical Documentation Gaps Callout */}
        {!isAnalyzing &&
          ((analysis?.missingHistoryQuestions?.length || 0) > 0 ||
            (analysis?.missingExamFindings?.length || 0) > 0) && (
            <div className="mb-4 bg-blue-50/90 border border-blue-200 rounded-xl p-3.5 text-xs text-blue-950 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-bold text-blue-900">
                  <ClipboardCheck className="w-4 h-4 text-blue-700" />
                  <span>Clinical Documentation Gaps Identified</span>
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full border border-blue-200">
                  Quality Audit
                </span>
              </div>
              <p className="text-[11px] text-blue-800 leading-relaxed">
                CuraDoc AI detected vital history questions and physical examination maneuvers that have not yet been documented for this clinical presentation.
              </p>
              <div className="flex items-center gap-2 pt-0.5 flex-wrap">
                {(analysis?.missingHistoryQuestions?.length || 0) > 0 && (
                  <button
                    onClick={() => setActiveTab('historyGaps')}
                    className="px-2.5 py-1 bg-white hover:bg-blue-100 border border-blue-300 rounded-lg text-[11px] font-semibold text-blue-900 flex items-center gap-1 shadow-2xs transition-colors cursor-pointer"
                  >
                    <HelpCircle className="w-3 h-3 text-blue-700" />
                    <span>Review {analysis?.missingHistoryQuestions?.length} Missing History Questions</span>
                  </button>
                )}
                {(analysis?.missingExamFindings?.length || 0) > 0 && (
                  <button
                    onClick={() => setActiveTab('examGaps')}
                    className="px-2.5 py-1 bg-white hover:bg-teal-100 border border-teal-300 rounded-lg text-[11px] font-semibold text-teal-900 flex items-center gap-1 shadow-2xs transition-colors cursor-pointer"
                  >
                    <Activity className="w-3 h-3 text-teal-700" />
                    <span>Review {analysis?.missingExamFindings?.length} Missing Exam Maneuvers</span>
                  </button>
                )}
              </div>
            </div>
          )}

        {/* Missing Info Alert Box */}
        {!isAnalyzing && analysis?.clinicalMissingInfoAlerts && analysis.clinicalMissingInfoAlerts.length > 0 && (
          <div className="mb-4 bg-stone-100/90 border border-stone-300/80 rounded-lg p-3 text-xs text-stone-800">
            <div className="flex items-center gap-1.5 font-semibold text-stone-900 mb-1">
              <Info className="w-3.5 h-3.5 text-stone-600" />
              <span>Recommended Information to Obtain:</span>
            </div>
            <ul className="list-disc list-inside space-y-0.5 text-stone-700 pl-1">
              {analysis.clinicalMissingInfoAlerts.map((alert, i) => (
                <li key={i}>{alert}</li>
              ))}
            </ul>
          </div>
        )}

        {/* TAB 1: DIFFERENTIAL DIAGNOSES */}
        {!isAnalyzing && activeTab === 'differentials' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
              <span>Differential considerations prioritized by clinical probability:</span>
              <span className="font-mono text-[11px]">{analysis?.differentials.length || 0} findings</span>
            </div>

            {(!analysis || analysis.differentials.length === 0) ? (
              <div className="bg-white rounded-lg border border-stone-200 p-8 text-center text-xs text-stone-500 space-y-3">
                <Stethoscope className="w-8 h-8 text-stone-400 mx-auto" />
                <p>No differentials analyzed yet.</p>
                <button
                  onClick={onAnalyze}
                  className="px-4 py-2 bg-stone-900 text-white rounded-md text-xs font-medium hover:bg-stone-800 transition-colors"
                >
                  Analyze Note with Clinical AI
                </button>
              </div>
            ) : (
              analysis.differentials.map((diff, idx) => {
                const itemKey = `diff-${idx}`;
                const isInserted = insertedItems[itemKey];

                return (
                  <div key={idx} className="bg-white rounded-lg border border-stone-200/90 p-4 shadow-2xs space-y-2.5 transition-all">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-bold text-stone-900">{diff.diagnosis}</h3>
                          <span className="text-stone-400 font-mono text-xs">·</span>
                          <span className="font-mono text-xs text-stone-600 font-medium">{diff.icd10}</span>
                        </div>
                        <div className="text-xs text-stone-500 mt-0.5">
                          Likelihood:{' '}
                          <span
                            className={`font-semibold ${
                              diff.likelihood === 'High'
                                ? 'text-amber-800'
                                : diff.likelihood === 'Moderate'
                                ? 'text-stone-700'
                                : 'text-stone-500'
                            }`}
                          >
                            {diff.likelihood} Probability
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          const insertionText = `• ${diff.diagnosis} (${diff.icd10}) [${diff.likelihood} probability]\n  Reasoning: ${diff.reasoning}`;
                          onInsertIntoSection('assessment', insertionText);
                          markInserted(itemKey);
                        }}
                        className="flex items-center gap-1 text-xs font-medium text-stone-700 bg-stone-100/80 hover:bg-stone-200/80 border border-stone-200 px-2 py-1 rounded transition-colors shrink-0"
                        title="Insert into Assessment section"
                      >
                        {isInserted ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-700" />
                            <span className="text-emerald-800">Inserted</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3 h-3" />
                            <span>Insert</span>
                          </>
                        )}
                      </button>
                    </div>

                    <p className="text-xs text-stone-700 leading-relaxed">
                      {diff.reasoning}
                    </p>

                    {diff.recommendedWorkup && diff.recommendedWorkup.length > 0 && (
                      <div className="bg-stone-50/80 border border-stone-200/60 rounded p-2.5 text-xs space-y-1">
                        <span className="font-semibold text-stone-800 text-[11px] uppercase tracking-wider block">
                          Suggested Diagnostic Workup:
                        </span>
                        <div className="flex flex-wrap gap-x-3 gap-y-1 text-stone-600">
                          {diff.recommendedWorkup.map((wk, i) => (
                            <span key={i} className="inline-flex items-center gap-1">
                              <span className="text-stone-400 font-mono">→</span> {wk}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {diff.guidelineName && (
                      <div className="flex items-center gap-1.5 text-[11px] text-stone-500 pt-1 border-t border-stone-100 flex-wrap">
                        <BookOpen className="w-3 h-3 text-emerald-700 shrink-0" />
                        <span>Guideline: <strong className="font-semibold text-stone-700">{diff.guidelineName}</strong></span>
                        {diff.evidenceLevel && (
                          <span className="bg-emerald-50 text-emerald-800 px-1.5 py-0.5 rounded font-mono text-[10px] border border-emerald-200 font-bold">
                            {diff.evidenceLevel}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* TAB 2: SAFETY & DRUG ALERTS */}
        {!isAnalyzing && activeTab === 'safety' && (
          <div className="space-y-3">
            <div className="text-xs text-stone-500 mb-1">
              Safety monitoring for drug interactions, allergies, and contraindications:
            </div>

            {(!analysis || analysis.safetyAlerts.length === 0) ? (
              <div className="bg-white rounded-lg border border-stone-200 p-8 text-center text-xs text-stone-500 space-y-2">
                <ShieldCheck className="w-8 h-8 text-emerald-700 mx-auto" />
                <p className="font-semibold text-stone-800">No Critical Safety Contraindications Flagged</p>
                <p className="text-stone-500">Current medications and documented allergies do not trigger known high-risk drug-drug interactions.</p>
              </div>
            ) : (
              analysis.safetyAlerts.map((alert, idx) => {
                const itemKey = `alert-${idx}`;
                const isInserted = insertedItems[itemKey];

                const isCritical = alert.severity === 'critical';

                return (
                  <div
                    key={idx}
                    className={`rounded-lg border p-4 shadow-2xs space-y-2.5 transition-all ${
                      isCritical
                        ? 'bg-amber-50/50 border-amber-300'
                        : 'bg-white border-stone-200'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <AlertTriangle className={`w-4 h-4 shrink-0 ${isCritical ? 'text-rose-700' : 'text-amber-700'}`} />
                          <h3 className="text-sm font-bold text-stone-900">{alert.title}</h3>
                        </div>
                        <div className="text-xs text-stone-600 mt-1 flex items-center gap-2 flex-wrap">
                          <span>Severity: <strong className={isCritical ? 'text-rose-800' : 'text-amber-800'}>{alert.severity.toUpperCase()}</strong></span>
                          <span className="text-stone-300 font-mono">·</span>
                          <span>Involved: {alert.substances.join(' + ')}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          const insertionText = `SAFETY ALERT: ${alert.title}\nRecommendation: ${alert.recommendation}`;
                          onInsertIntoSection('plan', insertionText);
                          markInserted(itemKey);
                        }}
                        className="flex items-center gap-1 text-xs font-medium text-stone-700 bg-white hover:bg-stone-50 border border-stone-300 px-2 py-1 rounded shadow-2xs transition-colors shrink-0"
                        title="Insert into Plan"
                      >
                        {isInserted ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-700" />
                            <span className="text-emerald-800">Inserted</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3 h-3" />
                            <span>Insert</span>
                          </>
                        )}
                      </button>
                    </div>

                    <p className="text-xs text-stone-700 leading-relaxed">
                      {alert.description}
                    </p>

                    {alert.clinicalMechanism && (
                      <div className="bg-stone-50 border border-stone-200/60 rounded p-2 text-[11px] text-stone-700 space-y-0.5">
                        <span className="font-semibold text-stone-800 uppercase text-[10px] tracking-wider block">
                          Pharmacological Mechanism:
                        </span>
                        <p>{alert.clinicalMechanism}</p>
                      </div>
                    )}

                    <div className="bg-stone-50 border border-stone-200/80 rounded p-2.5 text-xs text-stone-800">
                      <strong className="text-stone-900">Clinical Recommendation:</strong> {alert.recommendation}
                    </div>

                    {alert.guidelineSource && (
                      <div className="flex items-center gap-1.5 text-[11px] text-stone-500 pt-1 border-t border-stone-100">
                        <BookOpen className="w-3 h-3 text-amber-800 shrink-0" />
                        <span>Guideline Reference: <strong className="font-semibold text-stone-700">{alert.guidelineSource}</strong></span>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* TAB: MISSING HISTORY QUESTIONS */}
        {!isAnalyzing && activeTab === 'historyGaps' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
              <span>Unasked diagnostic history questions to establish chronology & rule-outs:</span>
              <span className="font-mono text-[11px] font-semibold text-blue-900 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                {analysis?.missingHistoryQuestions?.length || 0} questions
              </span>
            </div>

            {(!analysis?.missingHistoryQuestions || analysis.missingHistoryQuestions.length === 0) ? (
              <div className="bg-white rounded-lg border border-stone-200 p-8 text-center text-xs text-stone-500 space-y-3">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                <p className="font-semibold text-stone-800">Comprehensive Patient History Documented</p>
                <p className="text-[11px] text-stone-500 max-w-sm mx-auto">
                  No critical unasked history questions were identified for this patient presentation.
                </p>
              </div>
            ) : (
              analysis.missingHistoryQuestions.map((q, idx) => {
                const itemKey = `hist-${q.id || idx}`;
                const isInserted = insertedItems[itemKey];
                const status = questionStatuses[q.id] || q.status;

                return (
                  <div
                    key={q.id || idx}
                    className={`bg-white rounded-xl border p-4 shadow-2xs space-y-3 transition-all ${
                      status === 'asked_negative'
                        ? 'border-emerald-200 bg-emerald-50/20'
                        : status === 'asked_positive'
                        ? 'border-amber-200 bg-amber-50/20'
                        : 'border-stone-200 hover:border-blue-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-blue-100 text-blue-900 border border-blue-200">
                            {q.domain}
                          </span>
                          {status === 'asked_negative' && (
                            <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                              Asked · Pertinent Negative
                            </span>
                          )}
                          {status === 'asked_positive' && (
                            <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-amber-100 text-amber-900">
                              Asked · Positive Finding
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-stone-900 text-xs sm:text-sm mt-2 leading-snug">
                          "{q.question}"
                        </h4>
                      </div>

                      <button
                        onClick={() => {
                          onInsertIntoSection('subjective', q.suggestedInsert);
                          markInserted(itemKey);
                        }}
                        className="flex items-center gap-1 text-xs font-semibold text-blue-900 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-2.5 py-1 rounded-lg transition-colors shrink-0 shadow-2xs cursor-pointer"
                        title="Insert into Subjective"
                      >
                        {isInserted ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-700" />
                            <span className="text-emerald-800">Inserted</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>+ Insert to Note</span>
                          </>
                        )}
                      </button>
                    </div>

                    <div className="bg-stone-50 border border-stone-200/80 rounded-lg p-2.5 text-xs text-stone-700">
                      <strong className="text-stone-900">Clinical Rationale:</strong> {q.rationale}
                    </div>

                    {/* Quick Response Toggles */}
                    <div className="flex items-center justify-between pt-1 border-t border-stone-100 text-[11px]">
                      <span className="text-stone-400 font-medium">Clinician Response Audit:</span>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            setQuestionStatuses((prev) => ({ ...prev, [q.id]: 'asked_negative' }));
                            onInsertIntoSection('subjective', `Pertinent Negative: Patient screened for ${q.domain.toLowerCase()} and denies symptoms.`);
                          }}
                          className={`px-2 py-0.5 rounded transition-colors ${
                            status === 'asked_negative'
                              ? 'bg-emerald-600 text-white font-bold'
                              : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                          }`}
                        >
                          Mark Negative
                        </button>
                        <button
                          onClick={() => {
                            setQuestionStatuses((prev) => ({ ...prev, [q.id]: 'asked_positive' }));
                            onInsertIntoSection('subjective', `Positive Finding: Patient confirms symptoms regarding ${q.domain.toLowerCase()}.`);
                          }}
                          className={`px-2 py-0.5 rounded transition-colors ${
                            status === 'asked_positive'
                              ? 'bg-amber-600 text-white font-bold'
                              : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                          }`}
                        >
                          Mark Positive
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* TAB: MISSING PHYSICAL EXAMINATION MANEUVERS */}
        {!isAnalyzing && activeTab === 'examGaps' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
              <span>High-yield bedside physical examination maneuvers recommended for this presentation:</span>
              <span className="font-mono text-[11px] font-semibold text-teal-900 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                {analysis?.missingExamFindings?.length || 0} maneuvers
              </span>
            </div>

            {(!analysis?.missingExamFindings || analysis.missingExamFindings.length === 0) ? (
              <div className="bg-white rounded-lg border border-stone-200 p-8 text-center text-xs text-stone-500 space-y-3">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                <p className="font-semibold text-stone-800">Physical Examination Thorough</p>
                <p className="text-[11px] text-stone-500 max-w-sm mx-auto">
                  All expected physical examination components have been addressed in the Objective section.
                </p>
              </div>
            ) : (
              analysis.missingExamFindings.map((m, idx) => {
                const itemKey = `exam-${m.id || idx}`;
                const isInserted = insertedItems[itemKey];
                const status = examStatuses[m.id] || m.status;

                return (
                  <div
                    key={m.id || idx}
                    className={`bg-white rounded-xl border p-4 shadow-2xs space-y-3 transition-all ${
                      status === 'normal'
                        ? 'border-emerald-200 bg-emerald-50/20'
                        : status === 'abnormal'
                        ? 'border-rose-200 bg-rose-50/20'
                        : 'border-stone-200 hover:border-teal-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-teal-100 text-teal-900 border border-teal-200">
                            {m.organSystem}
                          </span>
                          {status === 'normal' && (
                            <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                              Completed · Normal / Benign
                            </span>
                          )}
                          {status === 'abnormal' && (
                            <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-rose-100 text-rose-900">
                              Completed · Pathological / Positive
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-stone-900 text-xs sm:text-sm mt-2">
                          {m.maneuver}
                        </h4>
                      </div>

                      <button
                        onClick={() => {
                          onInsertIntoSection('objective', m.suggestedInsert);
                          markInserted(itemKey);
                        }}
                        className="flex items-center gap-1 text-xs font-semibold text-teal-900 bg-teal-50 hover:bg-teal-100 border border-teal-200 px-2.5 py-1 rounded-lg transition-colors shrink-0 shadow-2xs cursor-pointer"
                        title="Insert maneuver into Objective"
                      >
                        {isInserted ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-700" />
                            <span className="text-emerald-800">Inserted</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3.5 h-3.5" />
                            <span>+ Insert to Note</span>
                          </>
                        )}
                      </button>
                    </div>

                    <p className="text-xs text-stone-700 leading-relaxed">
                      {m.clinicalSignificance}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                      <div className="bg-emerald-50/60 p-2.5 rounded-lg border border-emerald-100 text-emerald-950">
                        <strong className="block text-emerald-900 font-bold mb-0.5">Normal Finding:</strong>
                        <span>{m.normalExpectation}</span>
                      </div>
                      <div className="bg-amber-50/60 p-2.5 rounded-lg border border-amber-100 text-amber-950">
                        <strong className="block text-amber-900 font-bold mb-0.5">Abnormal Finding:</strong>
                        <span>{m.abnormalIndication}</span>
                      </div>
                    </div>

                    {/* Quick Finding Documentation */}
                    <div className="flex items-center justify-between pt-1 border-t border-stone-100 text-[11px]">
                      <span className="text-stone-400 font-medium">Record Examination Outcome:</span>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            setExamStatuses((prev) => ({ ...prev, [m.id]: 'normal' }));
                            onInsertIntoSection('objective', `${m.organSystem}: ${m.maneuver} evaluated - normal finding: ${m.normalExpectation}`);
                          }}
                          className={`px-2 py-0.5 rounded transition-colors ${
                            status === 'normal'
                              ? 'bg-emerald-600 text-white font-bold'
                              : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                          }`}
                        >
                          Document Normal
                        </button>
                        <button
                          onClick={() => {
                            setExamStatuses((prev) => ({ ...prev, [m.id]: 'abnormal' }));
                            onInsertIntoSection('objective', `${m.organSystem}: ${m.maneuver} evaluated - positive abnormal finding: ${m.abnormalIndication}`);
                          }}
                          className={`px-2 py-0.5 rounded transition-colors ${
                            status === 'abnormal'
                              ? 'bg-rose-600 text-white font-bold'
                              : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                          }`}
                        >
                          Document Abnormal
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* TAB: PATIENT TRANSLATION */}
        {!isAnalyzing && activeTab === 'patient' && (
          <div className="space-y-4">
            {(!analysis || !analysis.patientSummary) ? (
              <div className="bg-white rounded-lg border border-stone-200 p-8 text-center text-xs text-stone-500 space-y-3">
                <HeartPulse className="w-8 h-8 text-stone-400 mx-auto" />
                <p>Run analysis to generate patient-accessible 6th-grade discharge instructions.</p>
                <button
                  onClick={onAnalyze}
                  className="px-4 py-2 bg-stone-900 text-white rounded-md text-xs font-medium hover:bg-stone-800 transition-colors"
                >
                  Generate Patient Summary
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-lg border border-stone-200 p-5 shadow-2xs space-y-4">
                
                {/* Header & Copy Button */}
                <div className="flex items-start justify-between gap-3 border-b border-stone-200/80 pb-3">
                  <div>
                    <h3 className="text-base font-bold text-stone-900">
                      {analysis.patientSummary.headline}
                    </h3>
                    <p className="text-xs text-stone-500 mt-0.5">
                      Plain-language discharge guidance written for patient & caregiver understanding.
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={handleCopyPatientSummary}
                      className="flex items-center gap-1 text-xs font-medium text-stone-700 bg-stone-100 hover:bg-stone-200/70 border border-stone-300 px-2.5 py-1.5 rounded transition-colors"
                    >
                      {copiedPatientSummary ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-700" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy for Patient</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        const fullDischarge = `PATIENT DISCHARGE INSTRUCTIONS:\n${analysis.patientSummary.plainLanguageOverview}\n\nInstructions:\n${analysis.patientSummary.keyInstructions.join('\n')}\n\nFollow-up:\n${analysis.patientSummary.followUp}`;
                        onInsertIntoSection('plan', fullDischarge);
                        markInserted('patient-summary-insert');
                      }}
                      className="flex items-center gap-1 text-xs font-medium text-white bg-stone-900 hover:bg-stone-800 px-2.5 py-1.5 rounded transition-colors"
                    >
                      {insertedItems['patient-summary-insert'] ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                      <span>Insert into Plan</span>
                    </button>
                  </div>
                </div>

                {/* Plain language overview */}
                <div className="space-y-1">
                  <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
                    What Is Happening In Your Body:
                  </span>
                  <p className="text-xs md:text-sm text-stone-800 leading-relaxed bg-stone-50/70 rounded p-3 border border-stone-200/60">
                    {analysis.patientSummary.plainLanguageOverview}
                  </p>
                </div>

                {/* Key Instructions */}
                <div className="space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
                    Steps to Follow at Home:
                  </span>
                  <ul className="space-y-1.5 text-xs text-stone-800">
                    {analysis.patientSummary.keyInstructions.map((inst, i) => (
                      <li key={i} className="flex items-start gap-2 bg-stone-50/40 p-2 rounded border border-stone-100">
                        <span className="font-mono text-stone-500 font-semibold">{i + 1}.</span>
                        <span>{inst}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Medication Schedule */}
                {analysis.patientSummary.medicationSchedule && analysis.patientSummary.medicationSchedule.length > 0 && (
                  <div className="space-y-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
                      How to Take Your Medicine:
                    </span>
                    <div className="space-y-1.5">
                      {analysis.patientSummary.medicationSchedule.map((med, i) => (
                        <div key={i} className="bg-stone-50 rounded border border-stone-200/70 p-2.5 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div>
                            <strong className="text-stone-900">{med.name}</strong>
                            <p className="text-stone-600 mt-0.5">{med.instructions}</p>
                          </div>
                          <span className="text-[11px] text-stone-500 italic shrink-0">
                            For: {med.purpose}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Red Flag Symptoms */}
                <div className="space-y-1.5 bg-rose-50/50 border border-rose-200/80 rounded-lg p-3 text-xs">
                  <span className="font-bold text-rose-900 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-700" />
                    When to Seek Immediate Emergency Medical Care:
                  </span>
                  <ul className="list-disc list-inside space-y-1 text-rose-950 pl-1 mt-1">
                    {analysis.patientSummary.redFlagSymptoms.map((rf, i) => (
                      <li key={i}>{rf}</li>
                    ))}
                  </ul>
                </div>

                {/* Follow up */}
                <div className="text-xs text-stone-700 border-t border-stone-200/80 pt-3">
                  <strong>Follow-up Appointment:</strong> {analysis.patientSummary.followUp}
                </div>

              </div>
            )}
          </div>
        )}

        {/* TAB 4: ICD-10 & CODING */}
        {!isAnalyzing && activeTab === 'icd10' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
              <span>Suggested ICD-10-CM diagnostic codes based on documentation:</span>
              <span className="font-mono text-[11px]">{analysis?.icd10Suggestions.length || 0} codes</span>
            </div>

            {(!analysis || analysis.icd10Suggestions.length === 0) ? (
              <div className="bg-white rounded-lg border border-stone-200 p-8 text-center text-xs text-stone-500 space-y-3">
                <BookOpen className="w-8 h-8 text-stone-400 mx-auto" />
                <p>No ICD-10 suggestions loaded.</p>
                <button
                  onClick={onAnalyze}
                  className="px-4 py-2 bg-stone-900 text-white rounded-md text-xs font-medium hover:bg-stone-800 transition-colors"
                >
                  Generate ICD-10 Suggestions
                </button>
              </div>
            ) : (
              analysis.icd10Suggestions.map((icd, idx) => {
                const itemKey = `icd-${idx}`;
                const isInserted = insertedItems[itemKey];

                return (
                  <div key={idx} className="bg-white rounded-lg border border-stone-200 p-3.5 shadow-2xs flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-sm text-stone-900 bg-stone-100 px-2 py-0.5 rounded">
                          {icd.code}
                        </span>
                        <span className="text-xs font-semibold text-stone-800">{icd.description}</span>
                      </div>
                      <div className="text-xs text-stone-500 flex items-center gap-2">
                        <span>Category: {icd.category}</span>
                        <span className="text-stone-300 font-mono">·</span>
                        <span className="italic">{icd.rationale}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        const insertion = `• ICD-10 ${icd.code}: ${icd.description}`;
                        onInsertIntoSection('assessment', insertion);
                        markInserted(itemKey);
                      }}
                      className="flex items-center gap-1 text-xs font-medium text-stone-700 bg-stone-100 hover:bg-stone-200/80 border border-stone-200 px-2 py-1 rounded transition-colors shrink-0"
                      title="Insert code into Assessment"
                    >
                      {isInserted ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-700" />
                          <span className="text-emerald-800">Inserted</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3 h-3" />
                          <span>Insert</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* TAB 5: ASK CLINICAL COPILOT */}
        {!isAnalyzing && activeTab === 'copilot' && (
          <div className="space-y-4">
            <div className="bg-white rounded-lg border border-stone-200 p-4 shadow-2xs space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-stone-700">
                Ask Evidence-Based Clinical Assistant
              </h3>
              <p className="text-xs text-stone-500">
                Query clinical guidelines, drug dosing adjustments, antibiotic coverage, or differential workup algorithms.
              </p>

              {/* Preset prompt buttons */}
              <div className="flex flex-wrap gap-1.5 text-[11px]">
                <button
                  onClick={() => setCopilotQuestion('What are guideline-directed medical therapies (GDMT) for newly diagnosed heart failure?')}
                  className="bg-stone-100 hover:bg-stone-200/80 text-stone-700 rounded px-2 py-1 transition-colors text-left"
                >
                  Heart Failure GDMT Guidelines
                </button>
                <button
                  onClick={() => setCopilotQuestion('First-line alternative antibiotics for pediatric otitis media with severe penicillin allergy?')}
                  className="bg-stone-100 hover:bg-stone-200/80 text-stone-700 rounded px-2 py-1 transition-colors text-left"
                >
                  Pediatric AOM Allergy Alternatives
                </button>
                <button
                  onClick={() => setCopilotQuestion('Renal dosing adjustments and safety monitoring for SGLT2 inhibitors and ACE inhibitors in CKD Stage 3?')}
                  className="bg-stone-100 hover:bg-stone-200/80 text-stone-700 rounded px-2 py-1 transition-colors text-left"
                >
                  SGLT2 & ACEi Renal Dosing
                </button>
              </div>

              <form onSubmit={handleAsk} className="flex gap-2">
                <input
                  type="text"
                  value={copilotQuestion}
                  onChange={(e) => setCopilotQuestion(e.target.value)}
                  placeholder="e.g. What is the rule-out algorithm for atypical chest pain with low HEART score?"
                  className="flex-1 text-xs border border-stone-300 rounded-md px-3 py-2 focus:outline-none focus:ring-1 focus:ring-stone-400 bg-stone-50/50"
                />
                <button
                  type="submit"
                  disabled={isCopilotLoading || !copilotQuestion.trim()}
                  className="bg-stone-900 text-white rounded-md px-3.5 py-2 text-xs font-medium hover:bg-stone-800 disabled:opacity-50 transition-colors flex items-center gap-1 shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isCopilotLoading ? 'Thinking...' : 'Ask'}</span>
                </button>
              </form>
            </div>

            {copilotAnswer && (
              <div className="bg-white rounded-lg border border-stone-200 p-4 shadow-2xs space-y-2">
                <div className="flex items-center justify-between text-xs text-stone-500 border-b border-stone-100 pb-2 flex-wrap gap-2">
                  <span className="font-bold text-stone-800">Clinical Co-Pilot Response:</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setCopilotAnswer(null);
                        setCopilotQuestion('');
                      }}
                      className="flex items-center gap-1 text-stone-500 hover:text-rose-700 transition-colors"
                      title="Clear query and response"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Clear Query</span>
                    </button>
                    <span className="text-stone-300 font-mono">·</span>
                    <button
                      onClick={() => onInsertIntoSection('plan', `Clinical Guidance:\n${copilotAnswer}`)}
                      className="flex items-center gap-1 text-stone-700 hover:text-stone-900 font-medium"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Insert into Plan</span>
                    </button>
                  </div>
                </div>
                <div className="text-xs text-stone-800 leading-relaxed whitespace-pre-wrap font-sans">
                  {copilotAnswer}
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
